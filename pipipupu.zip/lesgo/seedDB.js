const Book = require('./models/book');

const books = [
  { title: 'Book 1', author: 'Author 1', rating: 4.5 },
  { title: 'Book 2', author: 'Author 2', rating: 4.0 },
];

Book.insertMany(books, (err) => {
  if (err) {
    console.error('Error seeding the database');
  } else {
    console.log('Database seeded successfully');
  }
});