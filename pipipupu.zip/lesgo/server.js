const express = require('express');
const mongoose = require('mongoose');
const ejs = require('ejs');
const path = require('path');

const app = express();

const axios = require('axios');

app.get('/api/books', async (req, res) => {
  try {
    const response = await axios.get('https://www.googleapis.com/books/v1/volumes?q=javascript');
    const books = response.data.items.map((item) => ({
      title: item.volumeInfo.title,
      author: item.volumeInfo.authors.join(', '),
      rating: item.volumeInfo.averageRating || 'N/A',
    }));
    res.json(books);
  } catch (error) {
    console.error('Error fetching data from the Google Books API:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.get('/api/openlibrary', async (req, res) => {
  try {
    const response = await axios.get('https://openlibrary.org/api/books?bibkeys=ISBN:0451450523&format=json&jscmd=data');
    const bookData = response.data['ISBN:0451450523'];
    const book = {
      title: bookData.title,
      author: bookData.authors[0].name,
      rating: 'N/A',
    };
    res.json(book);
  } catch (error) {
    console.error('Error fetching data from the Open Library API:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

mongoose.connect('mongodb+srv://jija:Qqwerty123@cluster0.pypz54d.mongodb.net/jija', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const bookSchema = new mongoose.Schema({
  title: String,
  author: String,
  rating: Number,
});

const Book = mongoose.model('Book', bookSchema);

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.render('home');
});

app.get('/books', async (req, res) => {
  try {
    const books = await Book.find({}).exec();
    res.render('books', { books });
  } catch (err) {
    console.error('Error fetching books:', err);
    res.status(500).send('Internal Server Error');
  }
});



app.get('/about', (req, res) => {
  res.render('about');
});

let port = process.env.PORT;
if (port == null || port == "") {
  port = 3000;
}
app.listen(port, function(){
  console.log(`Server has started succesfully`);
});

// // mongodb+srv://jija:<password>@cluster0.pypz54d.mongodb.net/?retryWrites=true&w=majority

// // const express = require('express');
// // const mongoose = require('mongoose');
// // const ejs = require('ejs');
// // const path = require('path');

// // const app = express();
// // const port = process.env.PORT || 3000;

// // // Connect to MongoDB Atlas (replace 'your-mongodb-atlas-connection-string' with your actual connection string)
// // mongoose.connect('mongodb+srv://jija:Qqwerty123@cluster0.pypz54d.mongodb.net/jija', {
// //   useNewUrlParser: true,
// //   useUnifiedTopology: true,
// // });

// // // Define a book schema and model (you can place this in a separate 'models' folder)
// // const bookSchema = new mongoose.Schema({
// //   title: String,
// //   author: String,
// //   rating: Number,
// // });

// // const Book = mongoose.model('Book', bookSchema);

// // // Set the view engine to EJS and specify the views directory
// // app.set('view engine', 'ejs');
// // app.set('views', path.join(__dirname, 'views'));

// // // Serve static files (e.g., CSS)
// // app.use(express.static(path.join(__dirname, 'public')));

// // // Define routes
// // app.get('/', (req, res) => {
// //   res.render('home');
// // });

// // app.get('/books', async (req, res) => {
// //   try {
// //     // Fetch books from the database and send them as a response
// //     const books = await Book.find({}).exec();
// //     res.render('books', { books });
// //   } catch (err) {
// //     console.error('Error fetching books:', err);
// //     res.status(500).send('Internal Server Error');
// //   }
// // });

// // app.get('/about', (req, res) => {
// //   res.render('about');
// // });

// // // Start the server
// // app.listen(port, function () {
// //   console.log(`Server has started successfully`);
// // });


// const express = require('express');
// const mongoose = require('mongoose');
// const ejs = require('ejs');
// const path = require('path');
// const axios = require('axios');
// require('dotenv').config(); // Load environment variables

// const app = express();
// const port = process.env.PORT || 3000;

// // Connect to MongoDB Atlas
// mongoose.connect(process.env.MONGODB_URI, {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// });

// // Define a book schema and model
// const bookSchema = new mongoose.Schema({
//   title: String,
//   author: String,
//   rating: Number,
// });

// const Book = mongoose.model('Book', bookSchema);

// // Set the view engine to EJS and specify the views directory
// app.set('view engine', 'ejs');
// app.set('views', path.join(__dirname, 'views'));

// // Serve static files (e.g., CSS)
// app.use(express.static(path.join(__dirname, 'public')));

// // Define an endpoint to fetch book data from the Google Books API
// app.get('/api/books', async (req, res) => {
//   try {
//     const apiKey = process.env.GOOGLE_BOOKS_API_KEY;
//     const response = await axios.get(`https://www.googleapis.com/books/v1/volumes?q=javascript&key=${apiKey}`);
//     const books = response.data.items.map((item) => ({
//       title: item.volumeInfo.title,
//       author: item.volumeInfo.authors.join(', '),
//       rating: item.volumeInfo.averageRating || 'N/A',
//     }));
//     res.json(books);
//   } catch (error) {
//     console.error('Error fetching data from the Google Books API:', error);
//     res.status(500).json({ error: 'Internal Server Error' });
//   }
// });

// // Define an endpoint to fetch book data from the Open Library API
// app.get('/api/openlibrary', async (req, res) => {
//   try {
//     const response = await axios.get('https://openlibrary.org/api/books?bibkeys=ISBN:0451450523&format=json&jscmd=data');
//     const bookData = response.data['ISBN:0451450523'];
//     const book = {
//       title: bookData.title,
//       author: bookData.authors[0].name,
//       rating: 'N/A', // Open Library API does not provide ratings
//     };
//     res.json(book);
//   } catch (error) {
//     console.error('Error fetching data from the Open Library API:', error);
//     res.status(500).json({ error: 'Internal Server Error' });
//   }
// });

// // Define routes
// app.get('/', (req, res) => {
//   res.render('home');
// });

// app.get('/books', async (req, res) => {
//   try {
//     // Fetch books from the database
//     const books = await Book.find({}).exec();
//     res.render('books', { books });
//   } catch (err) {
//     console.error('Error fetching books:', err);
//     res.status(500).send('Internal Server Error');
//   }
// });

// app.get('/about', (req, res) => {
//   res.render('about');
// });

// // Start the server
// app.listen(port, () => {
//   console.log(`Server has started successfully`);
// });
